

var GAMES = ["csgo"];
var CODENAME = "tradeskinsfast";
var FULLNAME = "tradeskinsfast.com";