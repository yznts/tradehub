

var GAMES = ["csgo", "pubg", "h1z1"];
var CODENAME = "tradeitgg";
var FULLNAME = "tradeit.gg";