

var GAMES = ["csgo"];
var CODENAME = "csgosum";
var FULLNAME = "csgosum.com";