

var GAMES = ["csgo"];
var CODENAME = "skinsjar";
var FULLNAME = "skinsjar.com";