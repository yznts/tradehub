

var GAMES = ["csgo"];
var CODENAME = "csdeals";
var FULLNAME = "cs.deals";