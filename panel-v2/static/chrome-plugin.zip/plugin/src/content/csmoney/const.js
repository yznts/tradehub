

var GAMES = ["csgo"];
var CODENAME = "csmoney";
var FULLNAME = "cs.money";