

var GAMES = ["csgo"];
var CODENAME = "lootfarm";
var FULLNAME = "loot.farm";