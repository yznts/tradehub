
var GAMES = ["csgo"];
var CODENAME = "csgosell";
var FULLNAME = "csgosell.com";
