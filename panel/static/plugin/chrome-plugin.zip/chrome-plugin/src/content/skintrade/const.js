

var GAMES = ["csgo"];
var CODENAME = "skintrade";
var FULLNAME = "skin.trade";